﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace POE_Part3_23.Data.Migrations
{
    public partial class addforeignkeycontraints : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
